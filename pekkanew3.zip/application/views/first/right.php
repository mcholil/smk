<!--span start--> <!-- RIGHT BLOCK -->
	<div class="span9" id="content" >
	<!--row fluid start-->
	<div class="row-fluid">

	<div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert">&times;</button>
        <h4>Action Status</h4>
	</div>

	<div class="alert alert-info alert-block">
	<button type="button" class="close" data-dismiss="alert">&times;</button>
	<h4 class="alert-heading">Info!</h4>
	<a href="#">Pengumuman Pengurus</a>
	</div>
	
	<div class="navbar">
        <button class="btn btn-mid">Kirim SMS</button> 
	<button class="btn btn-mid">Cari</button> 
        </div>
        
	</div>
	<!--row fluid End-->

	<!--row fluid Start-->
	<div class="row-fluid">
	<!-- block header-->
	<div class="block">
	<div class="navbar navbar-inner block-header">
	<button class="btn">Spam</button> 
	<button class="btn">Filter</button> 
	</div>

	<div class="block-content collapse in">
	<div class="span12">
	<table class="table table-striped">

	<thead>

	<tr>
	<th><input class="uniform_on" type="checkbox" id="optionsCheckbox" value="option1"></th>
	<th>Tanggal</th>
	<th>Pengirim</th>
	<th>Isi</th>
	</tr>

	</thead>

	<tbody>

	<tr>
	<td><input class="uniform_on" type="checkbox" id="optionsCheckbox" value="option1"></td>
	<td>23-04-2014</td>
	<td><a href="profil.html">Otto</a></td>
	<td><a href="percakapan.html">Pesan dari bla bla tentang blabla</a></td>
	</tr>

	<tr>
	<td><input class="uniform_on" type="checkbox" id="optionsCheckbox" value="option1"></td>
	<td>23-04-2014</td>
	<td>Thornton</td>
	<td>@fat</td>
	</tr>

	<tr>
	<td><input class="uniform_on" type="checkbox" id="optionsCheckbox" value="option1"></td>
	<td>23-04-2014</td>
	<td>the Bird</td>
	<td>Thanks for Approval</td>
	</tr>

	<tr>
	<td><input class="uniform_on" type="checkbox" id="optionsCheckbox" value="option1"></td>
	<td>23-04-2014</td>
	<td>the Bird</td>
	<td>Thanks for Approval</td>
	</tr>

	<tr>
	<td><input class="uniform_on" type="checkbox" id="optionsCheckbox" value="option1"></td>
	<td>23-04-2014</td>
	<td>the Bird</td>
	<td>Thanks for Approval</td>
	</tr>

	<tr>
	<td><input class="uniform_on" type="checkbox" id="optionsCheckbox" value="option1"></td>
	<td>23-04-2014</td>
	<td>the Bird</td>
	<td>Thanks for Approval</td>
	</tr>

	<tr>
	<td><input class="uniform_on" type="checkbox" id="optionsCheckbox" value="option1"></td>
	<td>23-04-2014</td>
	<td>the Bird</td>
	<td>Thanks for Approval</td>
	</tr>

	<tr>
	<td><input class="uniform_on" type="checkbox" id="optionsCheckbox" value="option1"></td>
	<td>23-04-2014</td>
	<td>the Bird</td>
	<td>Thanks for Approval</td>
	</tr>

	<tr>
	<td><input class="uniform_on" type="checkbox" id="optionsCheckbox" value="option1"></td>
	<td>23-04-2014</td>
	<td>the Bird</td>
	<td>Thanks for Approval</td>
	</tr>

	<tr>
	<td><input class="uniform_on" type="checkbox" id="optionsCheckbox" value="option1"></td>
	<td>23-04-2014</td>
	<td>the Bird</td>
	<td>Thanks for Approval</td>
	</tr>

	<tr>
	<td><input class="uniform_on" type="checkbox" id="optionsCheckbox" value="option1"></td>
	<td>23-04-2014</td>
	<td>the Bird</td>
	<td>Thanks for Approval</td>
	</tr>
	</tbody>
	</table>
        </div>

        </div>
        </div>
	<!-- /block -->

	</div>	
        </div>
        <!--/.fluid-container-->
