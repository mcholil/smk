<?php

class Statistik_model extends CI_Model {

    	public function __construct() {
        parent::__construct();
        $this->load->database();
    	}

	
	public function get_wilayah() {
	$this->db->select('id_kab');
        $this->db->distinct('id_kab');       
	$this->db->from('dalam_proses');	
	
	$result = $this->db->get();	
	return $result;
    	}


	public function get_count_kecamatan() {
                
	$this->db->from('dalam_proses');	
	return $this->db->count_all_results();
    	}

	public function get_kecamatan($limit=10000, $offset=0) {

        $this->db->select('id_kec');
        $this->db->distinct('id_kec');       
	$this->db->from('dalam_proses');

	$this->db->limit($limit);
	$this->db->offset($offset);	
	$result = $this->db->get();
	return $result;	
    	}

	public function get_count_desa() {
        $this->db->select('id_desa');
        $this->db->distinct('id_desa');         
	$this->db->from('dalam_proses');	
	return $this->db->count_all_results();
    	}

	public function get_desa($limit=10000, $offset=0) {
        $this->db->select('id_desa');
        $this->db->distinct('id_desa');           
	$this->db->from('dalam_proses');
	$this->db->limit($limit);
	$this->db->offset($offset);	
	$result = $this->db->get();
	return $result;
    	}
	
	public function get_waktu() {
                
	$this->db->from('dalam_proses');	
	$result = $this->db->get();	
	return $result;
    	}
	
	public function get_kategori() {
                
	$this->db->from('dalam_proses');	
	$result = $this->db->get();
		
	return $result;
    	}
	
	public function get_kontemporer() {
                
	$this->db->from('dalam_proses');	
	$result = $this->db->get();
		
	return $result;
    	}
	
}?>
