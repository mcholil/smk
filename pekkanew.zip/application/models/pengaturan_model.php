<?php

class Pengaturan_model extends CI_Model {

    	public function __construct() {
        parent::__construct();
        $this->load->database();
    	}

	

	public function get_count_kategori() {
                
	$this->db->from('ref_kategori');	
	return $this->db->count_all_results();
    	}


	public function get_kategori($param) {
                
	// Kategori
	$this->db->from('ref_kategori');
	//
	switch($param['option'])
	{
		case 'all':
		$this->db->select('*');
		break;
			
		case 'paginate':
		$this->db->limit($param['limit'], $param['offset']);
		break;
			
		case 'by_id':
		$this->db->where('id', $param['id']);
		break;
		
	}	
	
	$result = $this->db->get();
	//
	return $result;
    	}

	public function get_wilayah($param) {
                
	$this->db->from('ref_kabupaten');

	switch($param['option'])
	{
					
		case 'by_id':
		$this->db->where('id', $param['id']);
		break;
		
	}
	
	$result = $this->db->get();
	return $result;
    	}
	
	public function get_count_kecamatan($param) {
                
	$this->db->from('ref_kecamatan');

	if(isset($param)) 
		{
			$this->db->where(id_kab, $param);
		}	
	return $this->db->count_all_results();
    	}



	public function get_kecamatan($param) {
                
	$this->db->from('ref_kecamatan');
	
	switch($param['option'])
	{
		case 'all':
		$this->db->select('*');
		break;
			
		case 'paginate':
		$this->db->limit($param['limit'], $param['offset']);
		break;
			
		case 'by_id':
		$this->db->where('id_kab', $param['id']);
		break;

		case 'by_id2':
		$this->db->where('id_kec', $param['id']);
		break;
		
	}
	
	$result = $this->db->get();
	return $result;	
    	}
	

	public function get_count_desa($param) {
                
	$this->db->from('ref_desa');	

	if(isset($param)) 
		{
			$this->db->where(id_kec, $param);
		}		
	
	return $this->db->count_all_results();
    	}



	public function get_desa($param) {
                
	$this->db->from('ref_desa');
	
	switch($param['option'])
	{
		case 'all':
		$this->db->select('*');
		break;
			
		case 'paginate':
		$this->db->limit($param['limit'], $param['offset']);
		break;
			
		case 'by_id':
		$this->db->where('id_kec', $param['id']);
		break;

		case 'by_id2':
		$this->db->where('id_desa', $param['id']);
		break;
		
	}
	
	$result = $this->db->get();
	return $result;
    	}


	public function get_grup($param) {
                
	
	$this->db->from('ref_group');	
	
	switch($param['option'])
	{
		case 'all':
		$this->db->select('*');
		break;
			
		case 'paginate':
		$this->db->limit($param['limit'], $param['offset']);
		break;
			
		case 'by_id':
		$this->db->where('id', $param['id']);
		break;
		
	}

	$result = $this->db->get();	
	return $result;
    	}


	// pengguna sistem

	public function get_count_pengguna() {
                
	$this->db->from('user');	
	return $this->db->count_all_results();
    	}
	

	public function get_pengguna($param) {
	
	$this->db->from('user');	
		
	switch($param['option'])
	{
		case 'all':
		$this->db->select('*');
		break;
			
		case 'paginate':
		$this->db->limit($param['limit'], $param['offset']);
		break;
			
		case 'by_id':
		$this->db->where('id', $param['id']);
		break;
		
	}

	$result = $this->db->get();	
	return $result;
    	}	




// --------------------------------------------------------------------
	
	/**
	 * Add Kategori
	 *
	 * @access	public   		 
	 * @return
	 */		
	function add_update($param)
	{
	
	switch($param['type'])
	{
	case 'kategori':
		
		$this->db->set('nama', $param['nama']);
		$this->db->set('keterangan', $param['keterangan']);

		if(!empty($param['id'])) 
			{
		$this->db->where('id', $param['id']);
		$this->db->update('ref_kategori');
		} else $this->db->insert('ref_kategori'); 
	
	break;	

	case 'wilayah':
		$this->db->set('nama', $param['nama']);
		if(!empty($param['id'])) 
			{
		$this->db->where('id', $param['id']);
		$this->db->update('ref_kabupaten');
		} else $this->db->insert('ref_kabupaten'); 
				 
	break;	

	case 'kecamatan':
		$this->db->set('nama', $param['nama']);
		$this->db->set('keterangan', $param['keterangan']);
				
		$this->db->insert('ref_kategori'); 
	break;	

	case 'desa':
		$this->db->set('nama', $param['nama']);
		$this->db->set('keterangan', $param['keterangan']);
				
		$this->db->insert('ref_kategori'); 
	break;

	case 'grup':
		$this->db->set('nama', $param['nama']);
		$this->db->set('keterangan', $param['keterangan']);
		if(!empty($param['id'])) 
			{
		$this->db->where('id', $param['id']);
		$this->db->update('ref_group');
		} else $this->db->insert('ref_group'); 
	break;

	case 'pengguna':
		$this->db->set('nama', $param['nama']);
		$this->db->set('alamat', $param['alamat']);
		$this->db->set('profesi', $param['profesi']);
		$this->db->set('no_hp', $param['no_hp']);
		$this->db->set('username', $param['username']);
		$this->db->set('password', $param['password']);
		if(!empty($param['id'])) 
			{
		$this->db->where('id', $param['id']);
		$this->db->update('user');
		} else $this->db->insert('user'); 
	break;
  	}
	}




}?>
