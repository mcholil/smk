<!-- LEFT BLOCK -->
	<div class="span3" id="sidebar">
		<ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
		<li class="active"> <a href="index.html"><i class="icon-chevron-right"></i> SMS Masuk</a> </li>
		<li> <a href="keluar.html"><i class="icon-chevron-right"></i> SMS Keluar</a> </li>
		<li> <a href="terkirim.html"> Terkirim</a> </li>
		<li> <a href="tertunda.html"> Tertunda</a> </li>
		<li> <a href="spam.html"><i class="icon-chevron-right"></i> Spam</a> </li>
		<li> <a href="sampah.html"><i class="icon-chevron-right"></i> Sampah</a> </li>
		<li> <a href="komersial.html"><i class="icon-chevron-right"></i> Komersial</a> </li>
                </ul>
	</div>
<!--/ LEFT BLOCK -->      
