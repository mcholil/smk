<title>SMS Gateway Monitoring Komunitas</title>
       
<link href="<?php echo $this->config->item('css_path');?>/rati/bootstrap.css" rel="stylesheet" media="screen">
<link href="<?php echo $this->config->item('css_path');?>/rati/bootstrap-responsive.css" rel="stylesheet" media="screen">
<link href="<?php echo $this->config->item('css_path');?>/rati/styles.css" rel="stylesheet" media="screen">   

<!--/ Header End -->
