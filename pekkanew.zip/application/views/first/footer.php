<script language="javascript" src="<?php echo $this->config->item('js_path');?>vendors/jquery-1.9.1.min.js"></script>          
<script language="javascript" src="<?php echo $this->config->item('js_path');?>bootstrap.min.js"></script>   
<script language="javascript" src="<?php echo $this->config->item('js_path');?>scripts.js"></script>   
<script language="javascript" src="<?php echo $this->config->item('js_path');?>loadscript.js"></script>
