function updateTextArea() {
         
    var allVals = [];
    $('#checkbox :checked').each(function() {
        allVals.push($(this).val());
    });
    $('#number').val(allVals)
}

$(function() {
    $('#checkbox input').click(updateTextArea);
    updateTextArea();
});

