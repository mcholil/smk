<?php

class Sms_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

	
	
	public function get_count_inbox() {
		$this->db->from('inbox');
		$this->db->where("(UDH = '' OR UDH LIKE '%1')",NULL);
		return $this->db->count_all_results();
    	}
	


	public function get_sms_inbox($limit=10000, $offset=0) {

	// Inbox dipecah (Inbox, Spam, Sampah, Komersial) berdasarkan type
		
        $this->db->from(inbox);
	$this->db->where("(UDH = '' OR UDH LIKE '%1')",NULL);	
	$this->db->order_by("ReceivingDateTime", "asc");
	$this->db->limit($limit);
	$this->db->offset($offset);
	$result = $this->db->get();
	// Tambahan untuk menampilkan UDH Multi Part Diulang dalam view	 

	
	return $result;
    	}
	

// fungsi get multipart (ambil UDH multi part yang tidak bernilai 1) 

	public function get_count_outbox(){
	$this->db->from('outbox');
	$this->db->where("(UDH = '' OR UDH LIKE '%1')",NULL);
	$this->db->limit($limit);
	$this->db->offset($offset);
	return $this->db->count_all("outbox");
	}

	public function get_sms_outbox($limit=10000, $offset=0) {
	
	$this->db->from(outbox);
	
	$this->db->order_by("SendingDateTime", "asc");
	$this->db->limit($limit);
	$this->db->offset($offset);
	$result = $this->db->get();
		
	return $result;
    	}

	public function get_count_sentitems() {
	$this->db->from('sentitems');
	$this->db->where("(UDH = '' OR UDH LIKE '%1')",NULL);
	return $this->db->count_all_results();
	}



	public function get_sms_sentitems($limit=10000, $offset=0) {
        
	$this->db->from(sentitems);
	$this->db->order_by("SendingDateTime", "asc");
	$this->db->limit($limit);
	$this->db->offset($offset);
	$result = $this->db->get();
		
	return $result;
    	}



	public function get_sms_percakapan($id=0) {
	
	$number = $this->get_number_by_id($id);	

	$sql = "(
                SELECT DestinationNumber as no, ID as id, SendingDateTime AS tgl, TextDecoded AS isi, 'out' AS
                tipe FROM sentitems
                WHERE DestinationNumber = '" . $number . "'
                )
                UNION (
                SELECT SenderNumber as no, ID as id, UpdatedInDB AS tgl, TextDecoded AS isi, 'in' AS
                tipe FROM inbox
                WHERE SenderNumber = '" . $number . "'
                )
                ORDER BY tgl DESC";    
        
        $result = $this->db->query($sql);
	       		
	return $result;
    	}

	
	public function get_number_by_id($id) {
        $sql = "SELECT SenderNumber as no_pengirim, ID as id FROM inbox where id = ?";
        $query = $this->db->query($sql, array($id));
        $hasil = $query->row();

        if ($hasil != null) {
            return $hasil->no_pengirim;
        } else {
            return NULL;
        }
   	}


	public function get_sms_multipart(){

	$this->db->from(inbox);
	$this->db->where("(UDH <> ''  OR UDH LIKE '%1')",NULL);
	        
	$result = $this->db->get();
		
	return $result;
	}


  // --------------------------------------------------------------------
	
	/**
	 * All About Send Sms
	 *
	 * @access	public   		 
	 */


	function send_sms($data)
	{
	
	// cek2 
	// Multipart message
	if($messagelength > $standar_length)
			{
	$UDH_length = 7;
	$multipart_length = $standar_length - $UDH_length; 
			
	// generate UDH
	$UDH = "050003";
	$hex = dechex(mt_rand(0, 255));
        $hex = str_pad($hex, 2, "0", STR_PAD_LEFT);
        $UDH .= strtoupper($hex);
	$data['UDH'] = $UDH;
						
	// split string
	$tmpmsg = $this->_get_message_multipart($data['sms'], $data['coding'], $multipart_length);			
				
	// count part message
	$part = count($tmpmsg);
	if($part < 10) $part = '0'.$part;
		
	// insert first part to outbox and get last outbox ID
	$data['option'] = 'multipart';
	$data['sms'] = $tmpmsg[0];
	$data['part'] = $part;
	// kirim ke route sms
	$outboxid = $this->_send_sms_route($data);
       				
	// ulangi pengiriman multipart
	for($i=1; $i<count($tmpmsg); $i++) 
	
	{
	// multipart sms
	$this->_send_sms_multipart($outboxid, $tmpmsg[$i], $i, $part, $data['coding'], $data['class'], $UDH);
        		
         }
	}
		else 
	{

	// single sms
	$data['option'] = 'single';
	// kirim ke route
	$this->_send_sms_route($data);
	// ok	
	}
	}




	function _send_sms_route($tmp_data)
	{

	$tmp_data['dest'] = str_replace(" ", "", $tmp_data['dest']);
        $tmp_data['dest'] = str_replace("-", "", $tmp_data['dest']);	

	$data = array (
		'InsertIntoDB' => date('Y-m-d H:i:s'),
		'SendingDateTime' => $tmp_data['date'],
		'DestinationNumber' => $tmp_data['dest'],
		'Coding' => $tmp_data['coding'],
		'Class' => $tmp_data['class'],
		'SenderID' => $tmp_data['SenderID'],
		'TextDecoded' => $tmp_data['textsms'],
                'RelativeValidity' => $tmp_data['validity'],
		'DeliveryReport' => $tmp_data['delivery_report']			
			);
					
		if($tmp_data['option']=='multipart')
		{
			$data['MultiPart'] = 'true'; 
			$data['UDH'] = $tmp_data['UDH'].$tmp_data['part'].'01'; 
		}
					
		$this->db->insert('outbox', $data);
		
		if($tmp_data['option']=='multipart') return $last_outbox_id;
	}


	// 

	function _send_sms_multipart($outboxid, $sms, $pos, $part, $coding, $class, $UDH) 
	{
		$code = $pos+1;
		if($code < 10) $code = '0'.$code;
		
		$data = array (
				'ID' => $outboxid,
				'UDH' => $UDH.$part.''.$code,
				'SequencePosition' => $pos+1,
				'Coding' => $coding,
				'Class' => $class,
				'TextDecoded' => $sms,
				);	
		$this->db->insert('outbox_multipart',$data);						
	}

  // --------------------------------------------------------------------
	/**
	 * Close All About Send Sms	 
	 */
  // --------------------------------------------------------------------
}?>
